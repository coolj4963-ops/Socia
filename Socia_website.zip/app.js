const $=s=>document.querySelector(s);const $$=s=>document.querySelectorAll(s);
let posts=[
 {user:"Maya",handle:"@maya",text:"Finally finished the new design. Keeping it simple this time.",likes:24,comments:3},
 {user:"Alex",handle:"@alexdev",text:"Working on something I’ve wanted to build for ages. More soon.",likes:41,comments:7}
];
let chats={Maya:["Hey! Welcome to Socia 👋","Thanks! This looks clean."],Alex:["You still building that project?","Yep, almost done."]};
let activeChat=null;

function renderFeed(){
 const feed=$("#feed");feed.innerHTML="";
 posts.forEach((p,i)=>feed.insertAdjacentHTML("beforeend",`<article class="post"><div class="post-top"><div class="avatar">${p.user[0]}</div><div><strong>${p.user}</strong><small>${p.handle} · now</small></div></div><div class="post-text">${escapeHtml(p.text)}</div><div class="actions"><button onclick="likePost(${i})">♡ ${p.likes}</button><button>💬 ${p.comments}</button><button>↗ Share</button></div></article>`));
 renderMyPosts();
}
function renderMyPosts(){const e=$("#myPosts");e.innerHTML=posts.filter(p=>p.user==="Jay").map(p=>`<article class="post"><div class="post-top"><div class="avatar">J</div><strong>Jay</strong></div><div class="post-text">${escapeHtml(p.text)}</div></article>`).join("")||'<p class="muted">Your posts will appear here.</p>'}
function likePost(i){posts[i].likes++;renderFeed()}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
$$(".nav").forEach(b=>b.onclick=()=>showView(b.dataset.view));
function showView(id){$$(".view").forEach(v=>v.classList.add("hidden"));$("#"+id).classList.remove("hidden");$$(".nav").forEach(n=>n.classList.toggle("active",n.dataset.view===id));if(id==="explore")renderPeople();if(id==="messages")renderChats()}
$("#focusPost").onclick=()=>{showView("home");$("#postText").focus()}
$("#postText").oninput=e=>$("#count").textContent=e.target.value.length+"/280";
$("#postForm").onsubmit=e=>{e.preventDefault();const t=$("#postText").value.trim();if(!t)return;posts.unshift({user:"Jay",handle:"@jay",text:t,likes:0,comments:0});$("#postText").value="";$("#count").textContent="0/280";renderFeed()}
function renderPeople(){let people=[["Maya","@maya"],["Alex","@alexdev"],["Chris","@chris"],["Nia","@nia"]];$("#people").innerHTML=people.map(x=>`<div class="person"><div style="display:flex;gap:11px;align-items:center"><div class="avatar">${x[0][0]}</div><div><b>${x[0]}</b><div class="muted">${x[1]}</div></div></div><button class="follow" onclick="this.textContent=this.textContent==='Follow'?'Following':'Follow'">Follow</button></div>`).join("")}
function renderChats(){let c=$("#chatList");c.innerHTML=Object.keys(chats).map(n=>`<button class="chat-user" onclick="openChat('${n}')"><b>${n}</b><br><small class="muted">${chats[n].at(-1)}</small></button>`).join("")}
function openChat(name){activeChat=name;$("#chatTitle").textContent=name;$("#chatBody").innerHTML=chats[name].map((m,i)=>`<div class="bubble ${i%2?'me':''}">${escapeHtml(m)}</div>`).join("");$("#chatBody").scrollTop=99999}
$("#msgForm").onsubmit=e=>{e.preventDefault();if(!activeChat)return;let t=$("#msgInput").value.trim();if(!t)return;chats[activeChat].push(t);$("#msgInput").value="";openChat(activeChat);renderChats()}
$("#search").oninput=e=>{const q=e.target.value.toLowerCase();if(q){showView("explore");$("#people").innerHTML=`<div class="card" style="padding:18px">Searching for <b>${escapeHtml(q)}</b>…</div>`}}
renderFeed();