SOCIA — local starter
Open index.html in a browser.

This is a front-end prototype with working local interactions:
- create posts
- likes
- follow buttons
- search
- demo DMs
- profile

For a real public social network, connect a backend/database and authentication.
